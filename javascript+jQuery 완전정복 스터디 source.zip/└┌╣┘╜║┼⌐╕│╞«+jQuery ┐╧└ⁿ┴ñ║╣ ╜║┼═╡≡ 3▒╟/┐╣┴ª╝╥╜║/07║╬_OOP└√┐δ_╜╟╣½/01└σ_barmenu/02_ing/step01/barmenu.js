function BarMenu() {
	// 프로퍼티 생성
	this.init();
	this.initEvent();
}

BarMenu.prototype.init = function() {
	console.log("init");
}

BarMenu.prototype.initEvent = function() {
	console.log("initEvent");
}